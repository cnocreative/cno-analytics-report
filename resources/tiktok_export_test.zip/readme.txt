Fictional TikTok-style export used to test the CNO importer.
